/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package views;



import com.jfoenix.controls.JFXPasswordField;
import com.jfoenix.controls.JFXTextField;
import dao.bd.EmployeDao;
import java.io.IOException;
import java.net.URL;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import models.Employe;
import views.utils.Utils;

/**
 * FXML Controller class
 *
 * @author Foumilayo
 */
public class ConnexionController implements Initializable {

    private TextField labNom;

    @FXML
    private Label lblErrors;

    private TextField labPwd;

    @FXML
    private Button btnValider;
    @FXML
    private JFXTextField loginTextField;
    @FXML
    private JFXPasswordField pwdTextField;
     private Utils utils;

  /*  public void handleButtonAction(MouseEvent event) {
        if (event.getSource() == btnValider) {
            
            if (nom().equals("Success")) {
                try {

                    //add you loading or delays - ;-)
                    Node node = (Node) event.getSource();
                    Stage stage = (Stage) node.getScene().getWindow();
                    //stage.setMaximized(true);
                    stage.close();
                    Scene scene = new Scene(FXMLLoader.load(getClass().getResource("/fxml/OnBoard.fxml")));
                    stage.setScene(scene);
                    stage.show();

                } catch (IOException ex) {
                    System.err.println(ex.getMessage());
                }
            } else {
            }

        }

    }*/

    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
        
        
    }
    /*public ConnexionController(){
         
    }*/

    Connection con = null;
    PreparedStatement preparedStatement = null;
    ResultSet resultSet = null;

    private String nom() {
        String nom = labNom.getText();
        String pwd = labPwd.getText();

        String sql = "SELECT * FROM utilisateur Where nom = ? and pwd = ?";

        try {
            preparedStatement = con.prepareStatement(sql);
            preparedStatement.setString(1, nom);
            preparedStatement.setString(2, pwd);
            resultSet = preparedStatement.executeQuery();
            if (!resultSet.next()) {
                lblErrors.setTextFill(Color.TOMATO);
                lblErrors.setText("Entrer un nom/password correct ");
                System.err.println("wrong logins --//");
                return "error";
            } else {
                lblErrors.setTextFill(Color.GREEN);
                 lblErrors.setText("Connexion réussi ..redirection..");
                 System.out.println("connexion reussi");
                 return "success";
            }

        } catch (SQLException ex) {
            System.out.println(ex.getMessage());
            return "exception";
            
        }
    }

    /*private void showDialog(String info, String header, String title) {
        Alert alert = new Alert(Alert.AlertType.CONFIRMATION);
        alert.setContentText(info);
        alert.setHeaderText(header);
        alert.showAndWait();
    }*/

    //@FXML
   /* private void handleButtonAction(javafx.scene.input.MouseEvent event) {
    }*/

    @FXML
    private void connectToDashboad(ActionEvent event) throws IOException {
        EmployeDao dao = new EmployeDao();
        Employe emp = dao.selectEmployeByLoginAndPwd(loginTextField.getText(), pwdTextField.getText());
        if(emp==null){
            lblErrors.setText("Incorrect");
        } else {
            utils.changeView(pwdTextField, "dashboard");
        }
    }
}
