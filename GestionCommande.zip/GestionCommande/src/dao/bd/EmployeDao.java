/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dao.bd;

import dao.general.DaoMysql;
import dao.general.IDao;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import models.Employe;

/**
 *
 * @author Foumilayo
 */
public class EmployeDao implements IDao<Employe>{
    
    private final String SQL_SELECT_BY_LOGIN_PWD="SELECT * FROM `employe` INNER JOIN `utilisateur` ON employe.idUtilisateur=utilisateur.idUser WHERE login=? AND pwd=?";
    private DaoMysql daoMysql;
    public EmployeDao() {
        daoMysql=new DaoMysql();
    }
    
    @Override
    public Employe add(Employe obj) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public List<Employe> selectAll() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    public Employe selectEmployeByLoginAndPwd(String login, String pwd){
        daoMysql.getConnection();
         daoMysql.initPS(SQL_SELECT_BY_LOGIN_PWD);
         PreparedStatement ps=daoMysql.getPstm();
         Employe employe=null;
        try {
            ps.setString(1, login);
            ps.setString(2, pwd);
            ResultSet rs=ps.executeQuery();
            while(rs.next()){
                employe=new Employe(rs.getString("nom"),
                        rs.getString("prenom"), 
                        rs.getString("email"), 
                        rs.getString("telephone")
                        );
            }
        } catch (SQLException ex) {
            Logger.getLogger(EmployeDao.class.getName()).log(Level.SEVERE, null, ex);
        }finally{
            daoMysql.closeConnection();
        }
         
         return employe;
    }
    
}
