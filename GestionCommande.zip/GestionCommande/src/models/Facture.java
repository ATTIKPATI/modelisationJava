/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package models;

/**
 *
 * @author Foumilayo
 */
public class Facture {
    private int montantReglement;
    private String dateReglement;
    private int numeroFacture;
    private String lieuLivraison;
    private int prixLivraison;
    
    public int getMontantReglement() {
        return montantReglement;
    }

    public void setMontantReglement(int montantReglement) {
        this.montantReglement = montantReglement;
    }
    
    public String getDateReglement() {
        return dateReglement;
    }

    public void setDateReglement(String dateReglement) {
        this.dateReglement = dateReglement;
    }
    
    public int getNumeroFacture() {
        return numeroFacture;
    }

    public void setNumeroFacture(int numeroFacture) {
        this.numeroFacture = numeroFacture;
    }
    public String getLieuLivraison() {
        return lieuLivraison;
    }

    public void setLieuLivraison(String lieuLivraison) {
        this.lieuLivraison = lieuLivraison;
    }
    
    public int getPrixLivraison() {
        return  prixLivraison;
    }

    public void setPrixLivraison(int  prixLivraison) {
        this. prixLivraison =  prixLivraison;
    }
    
    
}
