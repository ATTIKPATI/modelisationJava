/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package models;

/**
 *
 * @author Foumilayo
 */
public class Employe extends Utilisateur {
    private String matricule;
    private String login;
    private String pwd;
    private String service;

    public Employe() {
    }

    public Employe(String nom, String prenom, String email, String telephone) {
        super(nom, prenom, email, telephone);
    }
    
    

    public Employe(String matricule, String login, String pwd, String service, String nom, String prenom, String email, String telephone) {
        super(nom, prenom, email, telephone);
        this.matricule = matricule;
        this.login = login;
        this.pwd = pwd;
        this.service = service;
    }

    public Employe(String matricule, String login, String pwd, String service, int idUser, String nom, String prenom, String email, String telephone) {
        super(idUser, nom, prenom, email, telephone);
        this.matricule = matricule;
        this.login = login;
        this.pwd = pwd;
        this.service = service;
    }

    public String getMatricule() {
        return matricule;
    }

    public void setMatricule(String matricule) {
        this.matricule = matricule;
    }

    public String getLogin() {
        return login;
    }

    public void setLogin(String login) {
        this.login = login;
    }

    public String getPwd() {
        return pwd;
    }

    public void setPwd(String pwd) {
        this.pwd = pwd;
    }

    public String getService() {
        return service;
    }

    public void setService(String service) {
        this.service = service;
    }
    
    
    
}
