/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package models;



/**
 *
 * @author Foumilayo
 */
public class Commande {
     private int id;
     private String montant;
     private String dateCommande;
    
    
    
    //ManyToOne  
    private Client client;
    
    public Commande(String montant, String dateCommande, Client client) {
        this.montant = montant;
        this.dateCommande = dateCommande;
        this.client = client;
        
       
    }
    public Commande(int id, String montant, String dateCommande, Client client) {
        this.id = id;
        this.montant = montant;
        this.dateCommande = dateCommande;
        this.client = client;
       
        
    }
    
     public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }
    
    public String getMontant() {
        return montant;
    }

    public void setMontant(String montant) {
        this.montant = montant;
    }
    public String getDateCommande() {
        return dateCommande;
    }

    public void setDateCommande(String dateCommande) {
        this.dateCommande = dateCommande;
    }
    
    public Client getClient() {
        return client;
    }
    
    public void setClient(Client client) {
        this.client = client;
    }

    @Override
    public String toString() {
        return "Commande{" + "id=" + id + ", montant=" + montant + ", dateCommande=" + dateCommande + '}';
    }
    
    

    
}
