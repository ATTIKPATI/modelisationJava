/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package models;

/**
 *
 * @author Foumilayo
 */
public class Client extends Utilisateur{
     private String numeroClient;
     private String adresse;

    public Client() {
    }

    public Client(String nom, String prenom, String email, String telephone) {
        super(nom, prenom, email, telephone);
    }

    public Client(String numeroClient, String adresse, String nom, String prenom, String email, String telephone) {
        super(nom, prenom, email, telephone);
        this.numeroClient = numeroClient;
        this.adresse = adresse;
    }

    public Client(String numeroClient, String adresse, int idUser, String nom, String prenom, String email, String telephone) {
        super(idUser, nom, prenom, email, telephone);
        this.numeroClient = numeroClient;
        this.adresse = adresse;
    }

    public String getNumeroClient() {
        return numeroClient;
    }

    public void setNumeroClient(String numeroClient) {
        this.numeroClient = numeroClient;
    }

    public String getAdresse() {
        return adresse;
    }

    public void setAdresse(String adresse) {
        this.adresse = adresse;
    }
     

     
}
